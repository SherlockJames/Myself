
	var box=document.querySelector(".background")
	var num=0;
var zidanspeed=0.1*1000; 
var smpalanspeed=0.5*1000; 
var ecpalanspeed=3*1000; 
var bgpalanspeed=5*1000; 
	var bgshijian=setInterval(function(){
		num++;
		box.style.backgroundPositionY=num+"px";
	},20)
	
	var begin=document.querySelector(".begin")
	var title=document.querySelector(".title")
	var plan=document.querySelector(".myplane")
	begin.onclick=function(){
		title.style.display="none";
		begin.style.display="none";
		plan.style.display="inline-block";
		
		document.onmousemove=function(ev){
			var ev=ev||event;
			var x=ev.clientX;
			var y=ev.clientY;
			var le=x-box.offsetLeft-plan.offsetWidth/2;
			var to=y-box.offsetTop-plan.offsetHeight/2;
			if(le<0){ le=0; }
			if(to<0){ to=0; }
			if(le>box.offsetWidth-plan.offsetWidth){le=box.offsetWidth-plan.offsetWidth}
			if(to>box.offsetHeight-plan.offsetHeight){to=box.offsetHeight-plan.offsetHeight}
			plan.style.left=le+"px";
			plan.style.top=to+"px";
		}
		setInterval(crzidan,zidanspeed)
		
		setInterval(crsmplan,smpalanspeed)
		
		setInterval(crecplan,ecpalanspeed)
		
		setInterval(crbgplan,bgpalanspeed)
			
	}
	

	
	

